#ifndef WIN64_H
#define WIN64_H

#include <windows.h>

#ifdef WIN64API_EXPORTS
#define WIN64API __declspec(dllexport)
#else
#define WIN64API __declspec(dllimport)
#endif

typedef struct { int R, G, B, A; } Win64_Color;
typedef struct { int Left, Top, Right, Bottom; } Win64_Rect;
typedef struct { int X, Y; } Win64_Point;
typedef struct { int cx, cy; } Win64_Size;

typedef int WIN64_BOOL;
#define WIN64_TRUE  1
#define WIN64_FALSE 0

typedef HWND        WIN64_HWND;
typedef HDC         WIN64_HDC;
typedef HBRUSH      WIN64_HBRUSH;
typedef HPEN        WIN64_HPEN;
typedef HFONT       WIN64_HFONT;
typedef HBITMAP     WIN64_HBITMAP;
typedef HICON       WIN64_HICON;
typedef HCURSOR     WIN64_HCURSOR;
typedef HMENU       WIN64_MENU;
typedef HWND        WIN64_CONTROL;
typedef HWND        WIN64_TOOLBAR;
typedef HWND        WIN64_STATUSBAR;
typedef UINT_PTR    Win64_CtrlID;
typedef UINT_PTR    Win64_MenuID;
typedef UINT_PTR    Win64_TimerID;
typedef UINT_PTR    WIN64_TRAY;
typedef UINT_PTR    WIN64_HOTKEY;
typedef UINT_PTR    WIN64_TIMER;

#define WIN64_NULL_HWND     NULL
#define WIN64_NULL_HDC      NULL
#define WIN64_NULL_HBITMAP  NULL

enum {
    WIN64_PEN_SOLID = 0,
    WIN64_PEN_DASH,
    WIN64_PEN_DOT,
    WIN64_PEN_DASHDOT,
    WIN64_PEN_NULL
};

enum {
    WIN64_FILL_GRADIENT_H = 0,
    WIN64_FILL_GRADIENT_V
};

enum {
    WIN64_ALIGN_LEFT    = 0x0000,
    WIN64_ALIGN_CENTER  = 0x0001,
    WIN64_ALIGN_RIGHT   = 0x0002,
    WIN64_ALIGN_TOP     = 0x0004,
    WIN64_ALIGN_VCENTER = 0x0008,
    WIN64_ALIGN_BOTTOM  = 0x0010
};

enum {
    WIN64_WS_NORMAL = 0,
    WIN64_WS_MAXIMIZED,
    WIN64_WS_MINIMIZED
};

enum {
    WIN64_THEME_LIGHT = 0,
    WIN64_THEME_DARK
};

typedef struct {
    int X, Y;
    int Width, Height;
    WIN64_BOOL CenterScreen;
    WIN64_BOOL CanResize;
    WIN64_BOOL CanMinMax;
    WIN64_BOOL NoBorder;
    WIN64_BOOL TopMost;
    WIN64_BOOL NoTaskbar;
    WIN64_BOOL HighDpiAware;
    int InitState;
    Win64_Color BgColor;
    int CornerRadius;
    WIN64_BOOL EnableMica;
    WIN64_BOOL EnableAcrylic;
    const wchar_t* WindowClassName;
} Win64_WindowStyle;

typedef struct {
    Win64_Rect Position;
    Win64_Color BgColor;
    const wchar_t* FontName;
    int FontSize;
    int FontWeight;
    DWORD StyleEx;
    WIN64_BOOL Visible;
    WIN64_BOOL ReadOnly;
    WIN64_BOOL OwnerDraw;
} Win64_ControlStyle;

typedef struct {
    const wchar_t* IconPath;
    const wchar_t* TipText;
} Win64_TrayInfo;

typedef struct {
    WIN64_BOOL Ctrl;
    WIN64_BOOL Alt;
    WIN64_BOOL Shift;
    WIN64_BOOL Win;
    UINT Key;
} Win64_HotKeyInfo;

typedef struct Win64_MenuItem {
    Win64_MenuID ID;
    const wchar_t* Text;
    WIN64_BOOL Separator;
    WIN64_BOOL Enabled;
    WIN64_BOOL Checked;
    const struct Win64_MenuItem* SubMenu;
    int SubMenuCount;
} Win64_MenuItem;

typedef struct {
    WIN64_HDC hDC;
    Win64_Rect Rect;
    WIN64_BOOL Selected;
    WIN64_BOOL Focused;
    WIN64_BOOL Pressed;
    WIN64_BOOL Enabled;
    WIN64_BOOL Hover;
    const wchar_t* Text;
    void* UserData;
} Win64_DrawItem;

typedef WIN64_BOOL (*Win64_MsgCallback)(WIN64_HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
typedef void (*Win64_TimerCallback)(WIN64_HWND hWnd, Win64_TimerID timerID);
typedef void (*Win64_TrayCallback)(UINT msg, Win64_Point pt);
typedef void (*Win64_DrawCallback)(WIN64_CONTROL hCtrl, Win64_DrawItem* item);

WIN64API WIN64_HWND Win64_CreateWindow(const wchar_t* Title, const Win64_WindowStyle* Style);
WIN64API void Win64_SetWindowCallback(WIN64_HWND hWnd, Win64_MsgCallback Callback);
WIN64API void Win64_ShowWindow(WIN64_HWND hWnd, int nCmdShow);
WIN64API void Win64_HideWindow(WIN64_HWND hWnd);
WIN64API void Win64_MoveWindow(WIN64_HWND hWnd, int X, int Y, int Width, int Height);
WIN64API void Win64_CloseWindow(WIN64_HWND hWnd);
WIN64API void Win64_DestroyWindow(WIN64_HWND hWnd);
WIN64API void Win64_SetTopMost(WIN64_HWND hWnd, WIN64_BOOL TopMost);
WIN64API void Win64_SetIcon(WIN64_HWND hWnd, const wchar_t* IconPath);
WIN64API void Win64_SetTitle(WIN64_HWND hWnd, const wchar_t* Title);
WIN64API void Win64_SetTheme(WIN64_HWND hWnd, int Theme);
WIN64API void Win64_SetWindowBgColor(WIN64_HWND hWnd, Win64_Color Color1, Win64_Color Color2, int Mode);
WIN64API void Win64_RedrawWindow(WIN64_HWND hWnd);
WIN64API void Win64_MinimizeToTray(WIN64_HWND hWnd);
WIN64API void Win64_RestoreFromTray(WIN64_HWND hWnd);
WIN64API void Win64_MessageLoop(void);
WIN64API void Win64_QuitMessageLoop(int ExitCode);

WIN64API WIN64_TIMER Win64_SetTimer(WIN64_HWND hWnd, Win64_TimerID TimerID, UINT IntervalMs, Win64_TimerCallback Callback);
WIN64API void Win64_KillTimer(WIN64_HWND hWnd, Win64_TimerID TimerID);

WIN64API WIN64_MENU Win64_CreateMenu(WIN64_HWND hWnd, const Win64_MenuItem* Items, int Count);
WIN64API WIN64_MENU Win64_CreatePopupMenu(const Win64_MenuItem* Items, int Count);
WIN64API void Win64_TrackPopupMenu(WIN64_MENU hMenu, WIN64_HWND hWnd, int X, int Y);
WIN64API void Win64_EnableMenuItem(WIN64_MENU hMenu, Win64_MenuID ID, WIN64_BOOL Enable);
WIN64API void Win64_CheckMenuItem(WIN64_MENU hMenu, Win64_MenuID ID, WIN64_BOOL Checked);
WIN64API void Win64_DestroyMenu(WIN64_MENU hMenu);

WIN64API WIN64_TOOLBAR Win64_CreateToolbar(WIN64_HWND hWnd, const Win64_MenuItem* Buttons, int Count);
WIN64API void Win64_Toolbar_EnableButton(WIN64_TOOLBAR hToolbar, Win64_MenuID ID, WIN64_BOOL Enable);
WIN64API WIN64_STATUSBAR Win64_CreateStatusBar(WIN64_HWND hWnd, const int* PartWidths, int Count);
WIN64API void Win64_SetStatusText(WIN64_STATUSBAR hStatusBar, int Part, const wchar_t* Text);

WIN64API WIN64_TRAY Win64_CreateTray(WIN64_HWND hWnd, const Win64_TrayInfo* Info, Win64_TrayCallback Callback);
WIN64API void Win64_UpdateTray(WIN64_TRAY hTray, const Win64_TrayInfo* Info);
WIN64API void Win64_ShowTrayBalloon(WIN64_TRAY hTray, const wchar_t* Title, const wchar_t* Text, int IconType);
WIN64API void Win64_DestroyTray(WIN64_TRAY hTray);

WIN64API WIN64_HOTKEY Win64_RegisterHotKey(WIN64_HWND hWnd, int HotKeyID, const Win64_HotKeyInfo* Info);
WIN64API void Win64_UnregisterHotKey(WIN64_HWND hWnd, int HotKeyID);

WIN64API WIN64_CONTROL Win64_CreateLabel(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* Text, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateButton(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* Text, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateEdit(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* DefaultText, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateListBox(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateComboBox(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateTabControl(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateProgressBar(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateSlider(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateCheckBox(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* Text, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateRadioBox(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* Text, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreateGroupBox(WIN64_HWND hWnd, Win64_CtrlID ID, const wchar_t* Text, const Win64_ControlStyle* Style);
WIN64API WIN64_CONTROL Win64_CreatePanel(WIN64_HWND hWnd, Win64_CtrlID ID, const Win64_ControlStyle* Style);

WIN64API void Win64_SetControlDrawCallback(WIN64_CONTROL hCtrl, Win64_DrawCallback Callback);
WIN64API void Win64_SetControlText(WIN64_CONTROL hCtrl, const wchar_t* Text);
WIN64API void Win64_GetControlText(WIN64_CONTROL hCtrl, wchar_t* Buffer, int BufferLen);
WIN64API void Win64_EnableControl(WIN64_CONTROL hCtrl, WIN64_BOOL Enable);
WIN64API void Win64_ShowControl(WIN64_CONTROL hCtrl, WIN64_BOOL Show);
WIN64API void Win64_MoveControl(WIN64_CONTROL hCtrl, int X, int Y, int Width, int Height);
WIN64API void Win64_SetControlFont(WIN64_CONTROL hCtrl, WIN64_HFONT hFont);
WIN64API void Win64_SetControlUserData(WIN64_CONTROL hCtrl, void* UserData);
WIN64API void* Win64_GetControlUserData(WIN64_CONTROL hCtrl);

WIN64API void Win64_Edit_GetText(WIN64_CONTROL hEdit, wchar_t* Buffer, int BufferLen);
WIN64API void Win64_Edit_SetText(WIN64_CONTROL hEdit, const wchar_t* Text);
WIN64API void Win64_Edit_SetSel(WIN64_CONTROL hEdit, int Start, int End);
WIN64API void Win64_Edit_Append(WIN64_CONTROL hEdit, const wchar_t* Text);
WIN64API void Win64_Edit_SetReadOnly(WIN64_CONTROL hEdit, WIN64_BOOL ReadOnly);

WIN64API void Win64_ListBox_AddItem(WIN64_CONTROL hListBox, const wchar_t* Text);
WIN64API void Win64_ListBox_InsertItem(WIN64_CONTROL hListBox, int Index, const wchar_t* Text);
WIN64API void Win64_ListBox_DeleteItem(WIN64_CONTROL hListBox, int Index);
WIN64API void Win64_ListBox_Clear(WIN64_CONTROL hListBox);
WIN64API int Win64_ListBox_GetCount(WIN64_CONTROL hListBox);
WIN64API int Win64_ListBox_GetSel(WIN64_CONTROL hListBox);
WIN64API WIN64_BOOL Win64_ListBox_GetText(WIN64_CONTROL hListBox, int Index, wchar_t* Buffer, int BufferLen);
WIN64API void Win64_ListBox_SetSel(WIN64_CONTROL hListBox, int Index);

WIN64API void Win64_ComboBox_AddItem(WIN64_CONTROL hComboBox, const wchar_t* Text);
WIN64API void Win64_ComboBox_DeleteItem(WIN64_CONTROL hComboBox, int Index);
WIN64API void Win64_ComboBox_Clear(WIN64_CONTROL hComboBox);
WIN64API int Win64_ComboBox_GetCount(WIN64_CONTROL hComboBox);
WIN64API int Win64_ComboBox_GetSel(WIN64_CONTROL hComboBox);
WIN64API WIN64_BOOL Win64_ComboBox_GetText(WIN64_CONTROL hComboBox, int Index, wchar_t* Buffer, int BufferLen);
WIN64API void Win64_ComboBox_SetSel(WIN64_CONTROL hComboBox, int Index);

WIN64API void Win64_TabControl_AddPage(WIN64_CONTROL hTab, const wchar_t* Text);
WIN64API int Win64_TabControl_GetCurSel(WIN64_CONTROL hTab);
WIN64API void Win64_TabControl_SetCurSel(WIN64_CONTROL hTab, int Index);

WIN64API void Win64_Progress_SetRange(WIN64_CONTROL hProg, int Min, int Max);
WIN64API void Win64_Progress_SetPos(WIN64_CONTROL hProg, int Pos);
WIN64API int Win64_Progress_GetPos(WIN64_CONTROL hProg);
WIN64API void Win64_Progress_StepIt(WIN64_CONTROL hProg);

WIN64API void Win64_Slider_SetRange(WIN64_CONTROL hSlider, int Min, int Max);
WIN64API void Win64_Slider_SetPos(WIN64_CONTROL hSlider, int Pos);
WIN64API int Win64_Slider_GetPos(WIN64_CONTROL hSlider);

WIN64API WIN64_BOOL Win64_CheckBox_GetCheck(WIN64_CONTROL hCheck);
WIN64API void Win64_CheckBox_SetCheck(WIN64_CONTROL hCheck, WIN64_BOOL Checked);
WIN64API WIN64_BOOL Win64_Radio_GetCheck(WIN64_CONTROL hRadio);
WIN64API void Win64_Radio_SetCheck(WIN64_CONTROL hRadio, WIN64_BOOL Checked);

WIN64API WIN64_HDC Win64_GetDC(WIN64_HWND hWnd);
WIN64API WIN64_HDC Win64_BeginPaint(WIN64_HWND hWnd);
WIN64API void Win64_EndPaint(WIN64_HWND hWnd, WIN64_HDC hDC);
WIN64API void Win64_ReleaseDC(WIN64_HWND hWnd, WIN64_HDC hDC);
WIN64API WIN64_HDC Win64_CreateMemDC(WIN64_HDC hDC, int Width, int Height);
WIN64API void Win64_DeleteDC(WIN64_HDC hDC);
WIN64API void Win64_BitBlt(WIN64_HDC hDest, int X, int Y, int W, int H, WIN64_HDC hSrc, int SrcX, int SrcY, int Rop);
WIN64API void Win64_StretchBlt(WIN64_HDC hDest, int X, int Y, int W, int H, WIN64_HDC hSrc, int SrcX, int SrcY, int SrcW, int SrcH, int Rop);

WIN64API void Win64_SetBkMode(WIN64_HDC hDC, WIN64_BOOL Transparent);
WIN64API void Win64_SetTextColor(WIN64_HDC hDC, Win64_Color Color);
WIN64API void Win64_SetBkColor(WIN64_HDC hDC, Win64_Color Color);

WIN64API WIN64_HBRUSH Win64_CreateSolidBrush(Win64_Color Color);
WIN64API WIN64_HPEN Win64_CreatePen(int Style, int Width, Win64_Color Color);
WIN64API WIN64_HFONT Win64_CreateFont(const wchar_t* Name, int Size, int Weight, WIN64_BOOL Bold, WIN64_BOOL Italic, WIN64_BOOL Underline);
WIN64API void Win64_DeleteObject(HGDIOBJ hGdiObj);
WIN64API void* Win64_SelectObject(WIN64_HDC hDC, HGDIOBJ hObj);

WIN64API void Win64_FillRect(WIN64_HDC hDC, Win64_Rect Rect, WIN64_HBRUSH hBrush);
WIN64API void Win64_FillRectSolid(WIN64_HDC hDC, Win64_Rect Rect, Win64_Color Color);
WIN64API void Win64_FillRectGradient(WIN64_HDC hDC, Win64_Rect Rect, Win64_Color Color1, Win64_Color Color2, int Mode);
WIN64API void Win64_DrawRect(WIN64_HDC hDC, Win64_Rect Rect, WIN64_HPEN hPen);
WIN64API void Win64_DrawLine(WIN64_HDC hDC, int X1, int Y1, int X2, int Y2, WIN64_HPEN hPen);
WIN64API void Win64_DrawCircle(WIN64_HDC hDC, int X, int Y, int Radius, WIN64_HPEN hPen);
WIN64API void Win64_FillCircle(WIN64_HDC hDC, int X, int Y, int Radius, WIN64_HBRUSH hBrush);
WIN64API void Win64_DrawRoundRect(WIN64_HDC hDC, Win64_Rect Rect, int CornerRadius, WIN64_HPEN hPen);
WIN64API void Win64_FillRoundRect(WIN64_HDC hDC, Win64_Rect Rect, int CornerRadius, WIN64_HBRUSH hBrush);
WIN64API void Win64_DrawEllipse(WIN64_HDC hDC, Win64_Rect Rect, WIN64_HPEN hPen);
WIN64API void Win64_FillEllipse(WIN64_HDC hDC, Win64_Rect Rect, WIN64_HBRUSH hBrush);
WIN64API void Win64_DrawPolygon(WIN64_HDC hDC, Win64_Point* Points, int Count, WIN64_HPEN hPen);
WIN64API void Win64_FillPolygon(WIN64_HDC hDC, Win64_Point* Points, int Count, WIN64_HBRUSH hBrush);

WIN64API void Win64_DrawText(WIN64_HDC hDC, const wchar_t* Text, Win64_Rect Rect, int Align);
WIN64API void Win64_DrawTextEx(WIN64_HDC hDC, const wchar_t* Text, int Len, Win64_Rect Rect, UINT Format);
WIN64API Win64_Size Win64_MeasureText(WIN64_HDC hDC, const wchar_t* Text);

WIN64API WIN64_HBITMAP Win64_LoadBitmapFile(const wchar_t* FilePath);
WIN64API void Win64_DeleteBitmap(WIN64_HBITMAP hBmp);
WIN64API void Win64_DrawBitmap(WIN64_HDC hDC, Win64_Rect DestRect, WIN64_HBITMAP hBmp);
WIN64API void Win64_DrawBitmapEx(WIN64_HDC hDC, int X, int Y, int W, int H, WIN64_HBITMAP hBmp, int SrcX, int SrcY, int SrcW, int SrcH, BYTE Alpha);
WIN64API Win64_Size Win64_GetBitmapSize(WIN64_HBITMAP hBmp);
WIN64API WIN64_HICON Win64_LoadIconFile(const wchar_t* FilePath);
WIN64API WIN64_HCURSOR Win64_LoadCursorFile(const wchar_t* FilePath);

WIN64API WIN64_BOOL Win64_FileExists(const wchar_t* Path);
WIN64API WIN64_BOOL Win64_DirExists(const wchar_t* Path);
WIN64API WIN64_BOOL Win64_CreateDir(const wchar_t* Path);
WIN64API ULONGLONG Win64_GetFileSize(const wchar_t* Path);
WIN64API WIN64_BOOL Win64_DeleteFile(const wchar_t* Path);
WIN64API WIN64_BOOL Win64_CopyFile(const wchar_t* Src, const wchar_t* Dest, WIN64_BOOL Overwrite);
WIN64API WIN64_BOOL Win64_MoveFile(const wchar_t* Src, const wchar_t* Dest);
WIN64API void* Win64_ReadFileAll(const wchar_t* Path, UINT* OutSize);
WIN64API WIN64_BOOL Win64_WriteFileAll(const wchar_t* Path, const void* Data, UINT DataSize);
WIN64API WIN64_BOOL Win64_AppendFile(const wchar_t* Path, const void* Data, UINT DataSize);

WIN64API WIN64_BOOL Win64_IniReadString(const wchar_t* FilePath, const wchar_t* Section, const wchar_t* Key, wchar_t* OutBuf, int BufLen, const wchar_t* Default);
WIN64API int Win64_IniReadInt(const wchar_t* FilePath, const wchar_t* Section, const wchar_t* Key, int Default);
WIN64API WIN64_BOOL Win64_IniWriteString(const wchar_t* FilePath, const wchar_t* Section, const wchar_t* Key, const wchar_t* Value);
WIN64API WIN64_BOOL Win64_IniWriteInt(const wchar_t* FilePath, const wchar_t* Section, const wchar_t* Key, int Value);

WIN64API WIN64_BOOL Win64_RegReadString(HKEY RootKey, const wchar_t* SubKey, const wchar_t* ValueName, wchar_t* OutBuf, int BufLen);
WIN64API WIN64_BOOL Win64_RegWriteString(HKEY RootKey, const wchar_t* SubKey, const wchar_t* ValueName, const wchar_t* Value);
WIN64API WIN64_BOOL Win64_RegReadInt(HKEY RootKey, const wchar_t* SubKey, const wchar_t* ValueName, int* OutValue);
WIN64API WIN64_BOOL Win64_RegWriteInt(HKEY RootKey, const wchar_t* SubKey, const wchar_t* ValueName, int Value);

WIN64API WIN64_BOOL Win64_ClipboardHasText(void);
WIN64API WIN64_BOOL Win64_ClipboardGetText(wchar_t* Buffer, int BufferLen);
WIN64API WIN64_BOOL Win64_ClipboardSetText(const wchar_t* Text);
WIN64API void Win64_EnableDragDrop(WIN64_HWND hWnd, WIN64_BOOL Enable);
WIN64API void Win64_MsgBox(const wchar_t* Text, const wchar_t* Title, UINT Type);
WIN64API WIN64_BOOL Win64_OpenFileDialog(WIN64_HWND hWnd, const wchar_t* Filter, wchar_t* OutPath, int PathLen);
WIN64API WIN64_BOOL Win64_SaveFileDialog(WIN64_HWND hWnd, const wchar_t* Filter, wchar_t* OutPath, int PathLen);
WIN64API WIN64_BOOL Win64_BrowseFolderDialog(WIN64_HWND hWnd, const wchar_t* Title, wchar_t* OutPath, int PathLen);

WIN64API UINT Win64_GetTickCount(void);
WIN64API void Win64_Sleep(UINT Ms);
WIN64API void Win64_GetScreenSize(int* Width, int* Height);
WIN64API void Win64_GetWindowRect(WIN64_HWND hWnd, Win64_Rect* Rect);
WIN64API void Win64_GetClientRect(WIN64_HWND hWnd, Win64_Rect* Rect);
WIN64API void Win64_CenterWindow(WIN64_HWND hWnd);
WIN64API void Win64_SetWindowAlwaysOnTop(WIN64_HWND hWnd, WIN64_BOOL OnTop);
WIN64API const wchar_t* Win64_GetLastError(void);

#endif